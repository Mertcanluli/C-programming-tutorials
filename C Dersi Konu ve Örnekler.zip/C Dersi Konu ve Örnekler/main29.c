#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	// klavyeden taban de�eri girilen dik ��geni y�ld�zlar ile yapan c kodlama �rne�i...
	
	
	/*int i,j;
	int yukseklik;
	
	printf("Yuksekligi Giriniz: ");
	scanf("%d",&yukseklik);
	
	for(i=1;i<=yukseklik;i++)
	{
		for(j=1;j<=i;j++)
		{
			printf("*");
		}
		printf("\n");
	}
	*/
	
	
	
	// 1+5+9+13+...+81 olan toplama i�lemini c kodlama dili ile yap�n�z...
	
	
	/*int i,toplam=0;
	
	for(i=1;i<=81;i+=4)
	{
		toplam=toplam+i;
	}
	printf("%d",toplam);
	*/
	
	
	
	// 2 ler galibyet 0 lar beraberlik 1 ler ise ma�lubiyet temsilidir...
	
	
	/*int skor[10]={2,1,0,0,2,1,1,2,1,0};
	int i,puan=0;
	
	for(i=0;i<10;i++)
	{
		if(skor[i]==2)
		{
			puan=puan+3;
		}
		if(skor[i]==0)
		{
			puan=puan+1;
		}
	}
	if(puan>=12)
	{
		printf("Puaniniz: %d Ligde Kaldiniz...",puan);
	}
	else
	{
		printf("Puaniniz: %d Ligde Kalamadiniz...",puan);
	}
	*/
	
	
	
		
	
	
	
	
	
	
	
	
	
	
	return 0;
}
