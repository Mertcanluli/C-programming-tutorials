#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	/*int dizi[2][2];
	
	dizi[0][0]=10;
	dizi[0][1]=20;
	dizi[1][0]=30;
	dizi[1][1]=40;
	
	printf("Matrisin 0-0 da bulunan elemani: %d\n",dizi[0][0]);
	printf("Matrisin 0-1 de bulunan elemani: %d\n",dizi[0][1]);
	printf("Matrisin 1-0 da bulunan elemani: %d\n",dizi[1][0]);
	printf("Matrisin 1-1 de bulunan elemani: %d\n",dizi[1][1]);
	*/
	
	return 0;
}
/* �ok boyutlu dizilerde x ve y ekseni gibi d���n�lmesi laz�m."[]" 1.si yatay 2.si ise dikey s�tunlar� ifade eder...*/
