#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	/*char sehir[15];
	int i;
	
	for(i=0;i<3;i++)
	{
		printf("Sehiri Giriniz: ");
		scanf("%s",sehir);
		printf("Girdiginiz il: %s",sehir);
		printf("\n");
		
	}
	*/
	
	
	
	/*int dizi[100];
	int i,sayi;
	
	printf("Eleman Sayisi: ");
	scanf("%d",&sayi);
	
	for(i=0;i<sayi;i++)
	{
		printf("Dizinin %d. degerini girin: ", i+1);
		scanf("%d",&dizi[i]);
	}
	printf("\n\n");
	
	for(i=0;i<sayi;i++)
	{
		printf("%d ",dizi[i]);
	}
	*/
	return 0;
}
