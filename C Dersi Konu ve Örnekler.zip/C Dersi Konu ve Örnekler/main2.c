#include <stdio.h>
#include <stdlib.h>



int main() {
	
	char kitapad[100]="Avucumuzdaki Kelebek";
	char yazar[100]="Ahmet Serif Izgoren";
	char turu[100]="Hikaye";
	char sayfa[5]="99999";
	char basimyili[4]="2001";
	
	printf("##### Kitap Tanitim #####\n\n\n");
	printf("Kitap adi: %s \nKitap yazari: %s \n",kitapad,yazar);
	printf("Kitap turu: %s \n",turu);
	printf("Sayfa Sayisi: %s \n",sayfa);
	printf("Basim Yili: %s \n",basimyili);	
	
	return 0;
}

/* De�i�kene tan�mlanan limit kadar karakter ekrana bast�r�l�r, e�er daha fazla yaz�l�rsa geri kalan k�s�mlar yazd�r�lmaz...
Ekranda yazd�rma komutu i�in %s kullan�l�r...*/
