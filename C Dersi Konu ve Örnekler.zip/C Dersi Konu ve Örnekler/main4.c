#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(){
	
	int sinav1, sinav2, sinav3, proje, ortalama;
	
	sinav1=75;
	sinav2=70;
	sinav3=80;
	proje=95;
	ortalama=(sinav1+sinav2+sinav3+proje)/4;
	
	printf("Ortalama: %d",ortalama);	
	return 0;
}

/* int de�i�keni i�in %s yerine %d kullan�l�r. int oldu�u zaman tamsay� de�erlerini al�r. Yani 1.6566 yerine sadece 1 de�erini al�r...*/
