#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	char kelime[100];
	
	printf("Kelimeyi Giriniz: ");
	scanf("%s",kelime);
	
	printf("Kelimenin Harf Uzunlugu: %d",strlen(kelime));
	
	
	return 0;
}

// strlen() fonksiyonu sat�rdaki girdilerin ka� uzunlukta oldu�unu hesaplamada kullan�l�r...

