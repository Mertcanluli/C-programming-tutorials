#include <stdio.h>
#include <stdlib.h>

struct kitapbilgi
{
	char kitapad[20];
	char yazar[20];
	int fiyat;
	float puan;
};

int main() {
	
	struct kitapbilgi kb={"SekerPortakali","Vasconceulos",10,7.5};
	
	printf("Kitap Adi: %s\n",kb.kitapad);
	printf("Yazari: %s\n",kb.yazar);
	printf("Fiyati: %d\n",kb.fiyat);
	printf("Puani: %.2f",kb.puan);
	
	return 0;
}

// "struct" yap�lar�, aralar�nda mant�ksal ili�kiler olan fakat farkl� t�rde olan bilgilerdir diyebiliriz.
// struct yap�s� main in �st�nde yaz�l�r ve temel yap� olu�turulur.
// Daha sonra main i�inde gerekli atamalar yap�l�r ve ekrana yazd�rma komutu verilir...
