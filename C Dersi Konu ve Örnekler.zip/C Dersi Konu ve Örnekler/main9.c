#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	/*int sayi;
	sayi=5;
	
	if (sayi%2==0)
	{
		printf("Sayi Cifttir.");
	}
	else
	{
		printf("Sayi Tektir.");
	}*/
	
	
	
	/*int x;
	
	printf("Sayi Giriniz: ");
	scanf("%d",&x);
	printf("\n");
	
	if(x%5==0)
	{
		printf("Sayi 5 e tam bolunur.");
	}
	else
	{
		printf("Sayi 5 e tam bolunmez.");
	}
	*/
	
	
	/*int sayi;
	printf("Sayi Giriniz: ");
	scanf("%d",&sayi);
	printf("\n");
	
	if (sayi%3==0 && sayi%5==0)
	{
		printf("Sayi 3 e ve 5 e tam bolunur.");
	}
	else
	{
		printf("Sayi 3 e ve 5 e tam bolunmez.");
	}
	*/
	
	
	
	/*int sayi;
	printf("Sayi Giriniz: ");
	scanf("%d",&sayi);
	printf("\n");
	
	if (sayi%3==0 || sayi%5==0)
	{
		printf("Sayi 3 e veya 5 e tam bolunur.");
	}
	else
	{
		printf("Sayi 3 e veya 5 e tam bolunmez.");
	}
	*/
	
	
	
	/*printf("***Suyun Sicakliga Gore Halleri***");
	printf("\n\n");
	
	int derece;
	printf("Sicaklik Degerini Giriniz: ");
	scanf("%d",&derece);
	printf("\n");
	
	if(derece<=0)
	{
		printf("Su Buz Halindedir.");
	}
	if(derece>0 && derece<=100)
	{
		printf("Su Sivi Halindedir.");
	}
	if(derece>100)
	{
		printf("Su Gaz Halindedir.");
	}
	*/
	
	
	
	/*printf("***Ders Basari Harf Notu***");
	printf("\n\n");
	
	int s1,s2,s3,proje,ortalama;
	
	printf("Sinav 1 Notunuzu Giriniz: ");
	scanf("%d",&s1);
	printf("\n");
	
	printf("Sinav 2 Notunuzu Giriniz: ");
	scanf("%d",&s2);
	printf("\n");
	
	printf("Sinav 3 Notunuzu Giriniz: ");
	scanf("%d",&s3);
	printf("\n");
	
	printf("Proje Notunuzu Giriniz: ");
	scanf("%d",&proje);
	printf("\n");
	
	ortalama=(s1+s2+s3+proje)/4;
	
	printf("Ortalamaniz: %d",ortalama);
	printf("\n");
	
	if(ortalama<50)
	{
		printf("Harf Notunuz FF");
	}
	if(ortalama>=50 && ortalama<60)
	{
		printf("Harf Notunuz DD");
	}
	if(ortalama>=60 && ortalama<70)
	{
		printf("Harf Notunuz CC");
	}
	if(ortalama>=70 && ortalama<85)
	{
		printf("Harf Notunuz BB");
	}
	if(ortalama>=85)
	{
		printf("Harf Notunuz AA");
	}
	*/
		
	return 0;
}

/* Mod almak i�in (b�l�mden kalan i�in) "%" kullan�l�r.*/
/* Ve i�in "&&" kullan�l�r.*/
/* Veya i�in "||" kullan�l�r*/
/* E�it midir i�in "==" kullan�l�r.*/
/* E�it de�il midir i�in "!=" kullan�l�r.*/

