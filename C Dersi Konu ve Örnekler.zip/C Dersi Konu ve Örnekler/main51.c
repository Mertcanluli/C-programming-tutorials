#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	printf("********************");
	printf("\n");
	printf("**      MENU      **");
	printf("\n");
	printf("********************");
	printf("\n\n");
	
	printf("1. TOPLAMA ISLEMI\n");
	printf("2. CARPMA ISLEMI\n");
	printf("3. KARE BULMA\n");
	printf("4. KUP BULMA\n");
	printf("5. DENKLEM (5X^2+4X+3)");
	
	int s1,s2,sonuc,secim;
	
	printf("\n\n");
	
	printf("Islem Seciniz: ");
	scanf("%d",&secim);
	
	switch(secim)
	{
		case 1:
			printf("2 Sayi Giriniz: ");
			scanf("%d%d",&s1,&s2);
			sonuc=s1+s2;
			printf("Sonuc: %d",sonuc);
		break;
		
		case 2:
		    printf("2 Sayi Giriniz: ");
		    scanf("%d%d",&s1,&s2);
		    sonuc=s1*s2;
		    printf("Sonuc: %d",sonuc);
		break;	
		
		case 3:
			printf("Sayi Giriniz: ");
			scanf("%d",&s1);
			sonuc=s1*s1;
			printf("Sonuc: %d",sonuc);
			break;
			
		case 4:
			printf("Sayi Giriniz: ");
			scanf("%d",&s1);
			sonuc=s1*s1*s1;
			printf("Sonuc: %d",sonuc);
			break;
			
		case 5:
		    printf("Sayi Giriniz: ");
			scanf("%d",&s1);
			sonuc= 5*s1*s1+4*s1+3;
			printf("Sonuc: %d",sonuc);
			break;	
		    	
	}
	
	return 0;
}
