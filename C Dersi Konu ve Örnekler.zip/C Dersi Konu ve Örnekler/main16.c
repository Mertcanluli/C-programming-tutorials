#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	int sayi1,sayi2,sonuc;
	char islem;
	
	sayi1=15;
	sayi2=5;
	
	printf("Islemi Girin: ");
	scanf("%s",&islem);
	
	switch(islem)
	{
		case '+': sonuc=sayi1+sayi2;
		          printf("Sonuc: %d",sonuc); break;
		          
		case '-': sonuc=sayi1-sayi2;
		          printf("Sonuc: %d",sonuc); break;
		          
		case '*': sonuc=sayi1*sayi2;
		          printf("Sonuc: %d",sonuc); break;
		          
		case '/': sonuc=sayi1/sayi2;
		          printf("Sonuc: %d",sonuc); break;
		          
		default:printf("Hatali Giri�...");		  		  		       
	}
	
	
	return 0;
}
