#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	FILE *dosya;
	
	dosya=fopen("C:\\Users\\mertcan\\Desktop\\yeni.txt","w");
	
	
	return 0;
}
