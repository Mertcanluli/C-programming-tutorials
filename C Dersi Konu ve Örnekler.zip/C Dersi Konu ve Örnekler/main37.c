#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	char kitap[40];
	
	printf("Ad: ");
	scanf("%s",kitap);
	
	printf("%s",kitap);
	
	printf("\n");
	
	printf("%18s",kitap);
	
	printf("\n");
	
	printf("%20.5s",kitap);
	
	printf("\n");
	
	printf("%-20s",kitap);
	
	return 0;
	
}

// % yan�na de�er verdi�imiz zaman soldan (verilen de�er - ekrana yaz�lan de�er) bo�luk b�rakarak ifade edilir...
// % yan�na de�er ve . konulur ise yaz�lan de�erin uzunlu�una bak�l�p verilen de�er kadar ekrana yazd�r�l�r ve yine soldan bo�luk olur...
// %- ise bo�lu�u soldan de�il de sa�dan b�rakarak ekrana yazd�r�r...


