#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	double sayi,sonuc1,sonuc2;
	
	printf("Sayiyi Giriniz: ");
	scanf("%lf",&sayi);
	
	sonuc1=floor(sayi);
	printf("Sonuc: %.f",sonuc1);
	
	printf("\n");
	
	sonuc2=ceil(sayi);
	printf("Sonuc: %.f",sonuc2);
	
	// Say�lar� yuvarlama yaparken "floor" ve "ceil" kullan�l�r.
	// floor alta yuvarlar... ceil ise yukar� yuvarlama yapar...
	// double kullan�ld��� zaman "%lf" kullan�l�r...
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
