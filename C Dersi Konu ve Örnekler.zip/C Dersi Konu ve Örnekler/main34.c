#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	/*double sayi,sonuc;
	
	printf("Sayiyi Giriniz: ");
	scanf("%lf",&sayi);
	
	sonuc=fabs(sayi);
	
	printf("Sonuc: %.lf",sonuc);
	*/
	
	// Mutlak de�er bulmak i�in "fabs()" kullan�l�r...
	
	
	
	/*double sayi,sonuc;
	
	printf("Sayiyi Giriniz: ");
	scanf("%lf",&sayi);
	
	sonuc=log(sayi);
	
	printf("Sonuc: %.7lf",sonuc);
	*/
	
	// Logaritma i�in "log()" kullan�l�r....
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
