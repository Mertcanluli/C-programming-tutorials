#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	/*int en,boy,i,j;
	
	printf("En Degerini Giriniz: ");
	scanf("%d",&en);
	
	printf("Boy Degerini Giriniz: ");
	scanf("%d",&boy);
	
	for(i=1;i<=boy;i++)
	{
		for(j=1;j<=en;j++)
		{
			printf("*");
		}
		printf("\n");
	}
	*/
	
	
	
	/*int i,j,taban;
	
	printf("Taban Degerini Giriniz: ");
	scanf("%d",&taban);
	
	for(i=1;i<=taban;i++)
	{
		for(j=1;j<=i;j++)
		{
			printf("*");
		}
		printf("\n");
	}
	*/
	
	
	
	/*int i,j,uzunluk;
	printf("Taban uzunluk: ");
	scanf("%d",&uzunluk);
	printf("\n");
	
	for(i=1;i<=uzunluk;i++)
	{
		for(j=1;j<=uzunluk-i;j++)
		{
			printf(" ");
		}
	
		for(j=1;j<=i;j++)
		{
			printf(" *");
		}
		printf("\n");
		
	}
	*/
	
	return 0;
}
