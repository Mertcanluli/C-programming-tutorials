#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	FILE *dosya;
	
	char karakter;
	
	dosya=fopen("C:\\Users\\mertcan\\Desktop\\Deneme.txt","r");
	
	do
	{
	
	karakter=getc(dosya);
	
	printf("%c",karakter);
	}
	while(karakter!=EOF);
	fclose(dosya);
	
	return 0;
}
