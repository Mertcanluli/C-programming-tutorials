#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	int sayi;
	double sonuc;
	
	printf("Sayiyi Giriniz: ");
	scanf("%d",&sayi);
	
	sonuc=sqrt(sayi);
	
	printf("Sonuc: %.4f",sonuc);
	
	// Kare K�k� almak i�in "sqrt()" kullan�l�r. Tam say�dan sonraki basamaklar i�in %f inin aras�na "." konulur ve yan�na ka� basamak gelece�ini belirtebiliriz...
	
	return 0;
}
