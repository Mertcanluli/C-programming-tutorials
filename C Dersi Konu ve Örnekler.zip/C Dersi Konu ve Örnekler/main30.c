#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	// Hava Yolu �irketini extra kg �zeri el ve ba�aj �cretlerini g�steren c kodlama �rne�i...
	
	/*int normal,el,normaltutar,eltutar,toplam;
	
	printf("Normal Bagaj Kg: ");
	scanf("%d",&normal);
	
	printf("El Bagaj Kg: ");
	scanf("%d",&el);
	
	if(normal<15)
	{
		normaltutar=0;
	}
	else
	{
		normaltutar=(normal-15)*5;
	}
	
	if(el<8)
	{
		eltutar=0;
	}
	else
	{
		eltutar=(el-8)*4;
	}
	
	toplam=normaltutar+eltutar;
	
	printf("Toplam Ekstra Odemeniz: %d TL. IYI YOLCULUKLAR...",toplam);
	*/
	
	

	// Kafa kar��t�r�c� ve d���n�lmesi gereken soruuu!!!!!!!!!!
	
	/*int sayi1,sayi2,buyuk,kucuk,i,toplam=0;
	
	yeniden:
	
	printf("1.Sayi: ");
	scanf("%d",&sayi1);
	
	printf("2.Sayi: ");
	scanf("%d",&sayi2);
	
	if(sayi1==sayi2)
	{
		goto yeniden;
	}
	else
	{
		if(sayi1>sayi2)
		{
			buyuk=sayi1;
			kucuk=sayi2;
		}
		else
		{
			kucuk=sayi1;
			buyuk=sayi2;
		}
	}
	
	for(i=kucuk;i<=buyuk;i++)
	{
		toplam=toplam+i;
	}
	
	printf("Toplam: %d",toplam);
	*/
	
	
	
	/*int yaz,kis,ilkbahar,sonbahar,toplam;
	
	kis=320;
	ilkbahar=kis/4;
	yaz=ilkbahar*8;
	sonbahar=yaz/10;
	
	toplam=yaz+kis+ilkbahar+sonbahar;
	
	printf("Toplam: %d",toplam);
	*/
	
	
	
	/*int birler,onlar,yuzler,toplam,sayi;
	
	printf("Sayiyi Giriniz: ");
	scanf("%d",&sayi);
	
	birler=sayi%10;
	onlar=(sayi/10)%10;
	yuzler=sayi/100;
	
	toplam=birler+onlar+yuzler;
	
	printf("Toplam: %d",toplam);
	*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
