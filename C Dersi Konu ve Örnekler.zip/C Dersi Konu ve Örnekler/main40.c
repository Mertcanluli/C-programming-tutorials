#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	char kitapad[30], yazar[30], kitapyazar[60];
	
	printf("Kitap Adi ve Yazarini Giriniz: ");
	scanf("%s%s",kitapad,yazar);
	
	strcat(kitapyazar,kitapad);
	strcat(kitapyazar," ");
	strcat(kitapyazar,"<-->");
	strcat(kitapyazar,yazar);
	
	printf("\n\n");
	printf("%s",kitapyazar);
	
	// "strcat" fonksiyonu girdileri birle�tirme olay�nda yard�mc� olur. Girilen girdiler ekrana birle�tirilerek yaz�l�r...
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
