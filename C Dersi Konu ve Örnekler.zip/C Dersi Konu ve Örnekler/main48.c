#include <stdio.h>
#include <stdlib.h>

    void liste()
    {
    	printf("Ali Yildiz\n");
    	printf("Ali Mustafa\n");
    	printf("Ali Korkmaz\n");
    	printf("Mehmet Gungor\n");
    	printf("Ali Okyar");
	}

int main() {
	
	liste();
	
	return 0;
}

// " void " geriye de�er d�nd�rmeyen fonksiyonlarda kullan�l�r...

