#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	char bilgi[40];
	
	printf("Bilgiyi Giriniz: ");
	gets(bilgi);
	printf("\n");
	puts(bilgi);

	return 0;
}

// Puts ve Gets komutlar� scanf in i�levi ile ayn�d�r. Tek fark Puts ve Gets yaz�lan her �eyi ekranda okutur fakat scanf bo�luktan sonra okutmaz...
