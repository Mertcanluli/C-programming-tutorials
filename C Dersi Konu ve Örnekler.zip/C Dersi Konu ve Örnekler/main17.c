#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	/*int tekrakamlar[]={1,3,5,7,9};
	printf("%d",tekrakamlar[0]);
	*/
	
	
	
	/*char sehir[]={'a','n','k','a','r','a'};
	printf("%s",sehir);
	*/
	
	
	
	/*int sayilar[4];
	sayilar[0]=24;
	sayilar[1]=895;
	sayilar[2]=774;
	sayilar[3]=662;
	printf("%d",sayilar[2]);
	*/
	
	return 0;
}

// Dizilerde de�i�ken tan�mland�ktan sonra [] kullan�l�r. Bu dizini ka� elemana sahip oldu�unu g�sterir... Ard�ndan {} i�inde elemanlar yaz�l�r...
// Daha sonra printf ile ekrana yazd�rma yap�l�r ve [] i�inde hangi eleman�n se�ilece�i belirlenir. Ba�lang�� eleman� [0] d�r...

