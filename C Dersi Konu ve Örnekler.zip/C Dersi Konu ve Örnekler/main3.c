#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	char kitapad[100], yazar[100], sayfa[4], basimtarih[4], basimev[100], tur[100];
	
	printf("Kitap Adi: ");
	scanf("%s",kitapad);
	
	printf("Yazar Adi: ");
	scanf("%s", yazar);
	
	printf("Sayfa Sayisi: ");
	scanf("%s", sayfa);
	
	printf("Basim Tarihi: ");
	scanf("%s", basimtarih);
	
	printf("Basim Evi: ");
	scanf("%s", basimev);
	
	printf("Tur: ");
	scanf("%s", tur);
	
	printf("Girdiginiz Kitap Adi: %s\n",kitapad);
	printf("Girdiginiz Yazar Adi: %s\n",yazar);
	printf("Girdiginiz Sayfa Sayisi: %s\n",sayfa);
	printf("Girdiginiz Basim Tarihi: %s\n",basimtarih);
	printf("Girdiginiz Basim Evi: %s\n",basimev);
	printf("Girdiginiz Turu: %s\n",tur);
	
	/*scanf ile kullan�c�dan input al�n�r ve ilgili de�i�kene atan�r....
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
