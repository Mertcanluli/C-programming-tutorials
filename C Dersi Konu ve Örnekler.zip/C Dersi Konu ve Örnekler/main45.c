#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	int sayi=10;
	int sayi2=20;
	double sayi3=2.45;
	char kelime='a';
	
	printf("%d\n",sayi);
	printf("%d\n",sayi2);
	printf("%f\n",sayi3);
	printf("%c\n",kelime);
	
	printf("\n\n\n *****    Bellek Adresleri *****    \n\n\n");
	
	printf("%x\n",&sayi);
	printf("%x\n",&sayi2);
	printf("%x\n",&sayi3);
	printf("%x",&kelime);
	
	return 0;
}

// "pointer" yap�lar�n bellekte bulunan adreslerini g�sterme k�sm�nda yard�mc� olur...
// "&" ile adres atamas� yap�l�r...
