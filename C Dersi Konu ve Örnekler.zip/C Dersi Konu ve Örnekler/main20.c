#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main () {
	
	/*int i;
	for(i=1;i<=5;i++)
	{
		printf("*****\n");
	}
	*/
	
	
	
	/*int i,j;
	for(i=1;i<=5;i++)
	{
		for(j=1;j<=i;j++)
		{
			printf("*");
		}
		printf("\n");
	}
	*/
	
	
	
	/*int i,j;
	for(i=1;i<=5;i++)
	{
		for(j=1;j<=2;j++)
		{
			printf("*");
		}
		printf("\n");
	}
	*/
	
	return 0;
}
/*Yildiz ile �ekil olu�turmada iki tane de�i�kene ihtiya� vard�r. Birisi ad�m di�eri ise ekrana yazd�r�lacak olan �ekil i�indir...*/
