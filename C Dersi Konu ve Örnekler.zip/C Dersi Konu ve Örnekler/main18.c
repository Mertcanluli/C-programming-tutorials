#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	/*int sayilar[]={1,3,5,7,9};
	int i;
	
	for (i=0;i<5;i++)
	{
		printf("%d\n",sayilar[i]);
	}
	*/
	
	
	
	/*int sayilar[]={10,15,20,25,30};
	int i;
	int toplam=0;
	
	for(i=0;i<5;i++)
	{
		toplam=toplam+sayilar[i];
	}
	printf("Toplam: %d",toplam);
	*/
		
	return 0;
}
