#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	int su,kola,misir,bilet,toplam;
	
	printf("Su Adeti: ");
	scanf("%d",&su);
	
	printf("Kola Adeti: ");
	scanf("%d",&kola);
	
	printf("Misir Adeti: ");
	scanf("%d",&misir);
	
	printf("Bilet Adeti: ");
	scanf("%d", &bilet);
	
	toplam= su*1+ kola*2+ misir*2+ bilet*8;
	 
	printf("Toplam Borcunuz: %d",toplam);
	printf(" TL...");	
	return 0;
}

/* int de�i�keni i�in kullan�c�dan veri almak scanf kullan�l�r "%d" ile ve adresi tan�mlamak i�in "&" sembol� kullan�l�r...*/
