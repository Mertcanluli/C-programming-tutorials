#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	int sayi=20;
	int *s=&sayi;

	printf("%d\n",sayi);
	printf("Bellek Adresi: %x",s);
	
	printf("\n\n ---------- \n\n");
	
	char harf='a';
	char *h=&harf;
	
	printf("%c\n",harf);
	printf("Bellek Adresi: %x",h);
	
	return 0;
}

// " * " ekleyerek pointer kullan�ld�� anla��l�r.
