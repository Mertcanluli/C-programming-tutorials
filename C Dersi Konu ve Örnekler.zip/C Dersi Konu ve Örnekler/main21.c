#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	/*int i,j;
	for(i=1;i<=5;i++)
	{
		for(j=5;j>=i;j--)
		{
			printf("*");
		}
		printf("\n");
    }
    */
	
	
	
	/*int i,j,k,l;
	
	for(i=1;i<=5;i++)
	{
		for(j=1;j<=i;j++)
		{
			printf("*");
		}
		printf("\n");
	}
	
	
	for(k=1;k<=5;k++)
	{
		for(l=5;l>=k;l--)
		{
			printf("*");
		}
		printf("\n");
	}
	*/
	
	
	
	/*int i,j,k,l;
	 
    for(i=1;i<=5;i++)
    {
    for(j=1;j<=i;j++)
    {
    printf("*");
    }
    for(j=1;j<=10-2*i;j++)
    {
    printf(" ");
    }
    for(j=1;j<=i;j++)
    {
    printf("*");
    }
    printf("\n");
	}     
    for(k=0;k<=4;k+=1)
    {
    for(l=4;l>=k;l-=1)
    {
    printf("*");
    }
    for(l=1;l<=2*k;l+=1)
    {
    printf(" ");
    }
    for(l=4;l>=k;l-=1)
    {
    printf("*");
    }
    printf("\n");
    }
	*/
	return 0;
}
