#include <stdio.h>
#include <stdlib.h>

// �� basamakl� rakamlar� birbirinden farkl� ka� tane say� oldu�unu bulan c dili kodlama �rne�i...

int main() {
	
	/*int sayac=0;
	int i;
	int a,b,c;
	
	for(i=100;i<=999;i++)
	{
		a=i/100;
		b=(i/10)%10;
		c=i%10;
		if(a!=b && a!=c && b!=c)
		{
			sayac++;
		}
	}
	printf("%d",sayac);
	*/
	
	
	// Klavyeden girilen say�n�n tam say� b�lenlerini bulan c kodu �rne�i...
	
	/*int sayi,i;
	
	printf("Sayiyi Giriniz: ");
	scanf("%d",&sayi);
	
	for(i=1;i<=sayi;i++)
	{
		if(sayi%i==0)
		{
			printf("%d\n",i);
		}
	}
	*/
	
	
	
	// klavyeden girilen de�erin k�p�n� bulan c kodlama �rne�i...
	
	
	/*int sayi,sonuc;
	
	printf("Sayiyi Giriniz: ");
	scanf("%d",&sayi);
	
	sonuc=sayi*sayi*sayi;
	
	printf("%d",sonuc);
	*/
	
	return 0;
}
