#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	/*int i;
	
	for(i=1;i<=10;i++)
	{
		printf("Hello World...\n");
	}
	*/
	
	
	
	/*int j;
	
	for(j=1;j<=35;j++)
	{
		printf("%d - Merhaba Izmir\n",j);
	}
	*/
	
	
	
	/*int j;
	
	for(j=0;j<=100;j+=2)
	{
		printf("%d\n",j);
	}
	*/
	
	
	
	/*int i;
	
	for(i=0;i<=30;i+=5)
	{
		printf("%d - Merhaba Trabzon\n",i);
	}
	*/
		
	return 0;
}

/* "for d�ng�s�" bize "tekrarlanan" output lar i�in kolayl�k sa�lar. for d�ng�s�nde �ncelikle de�i�kenin "ba�lang�� de�eri" verilir.
Daha sonra "maksimum ula�aca�� de�er" verilir. En son olarak da "hangi aral�kta artaca��" verilir...*/
/* for d�ng�s�nde "++" --> 1 er 1 er artt�rmak demektir...
                  "+=2" --> 2 �er 2 �er artt�rmak demektir...
                  "+=3" --> 3 er 3 er artt�rmak demektir �eklinde devam eder....*/
