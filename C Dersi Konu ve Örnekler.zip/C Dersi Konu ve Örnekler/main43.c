#include <stdio.h>
#include <stdlib.h>

   struct kayit
   {
   	char ad[20];
   	char soyad[20];
   	int no;
   	int sinif;
   	float ort;
    };

int main() {
	
	struct kayit ogrenci;
	
	printf("Ad: ");
	scanf("%s",&ogrenci.ad);
	
	printf("Soyad: ");
	scanf("%s",&ogrenci.soyad);
	
	printf("Numara: ");
	scanf("%d",&ogrenci.no);
	
	printf("Sinif: ");
	scanf("%d",&ogrenci.sinif);
	
	printf("Ortalama: ");
	scanf("%f",&ogrenci.ort);
	
	printf("\n");
	
	printf("%s\n",ogrenci.ad);
	printf("%s\n",ogrenci.soyad);
	printf("%d\n",ogrenci.no);
	printf("%d\n",ogrenci.sinif);
	printf("%.2f",ogrenci.ort);
		
	return 0;
}
