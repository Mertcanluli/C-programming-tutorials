#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	/*float maas,yenimaas;
	printf("***Zamli Maas Hesabi***\n");
	
	printf("Maasinizi Giriniz: ");
	scanf(" %f",&maas);
	
	yenimaas=maas+maas*25/100;
	
	printf("Zamli Maasiniz: %f",yenimaas);*/
	
	
	
	
	
	
	/*float pi,yaricap,alan,cevre;
	
	printf("***Cemberde Alan ve Cevre Hesabi***\n");
	
	pi=3.14;
	
	printf("Yaricap Degerini Giriniz: ");
	scanf("%f",&yaricap);
	
	alan=pi*yaricap*yaricap;
	cevre=2*pi*yaricap;
	
	printf("Alan Degeri: %f\n",alan);
	printf("Cevre Degeri: %f",cevre);*/
	
	
	
	
	
	
	/*float Turkce,matematik,sosyal,fen,taban,toplampuan;
	
	taban=100,160;
	
	printf("Turkce Netinizi Girin: ");
	scanf("%f",&Turkce);
	printf("\n");
	
	printf("Matematik Netinizi Girin: ");
	scanf("%f",&matematik);
	printf("\n");
	
	printf("Sosyal Netinizi Girin: ");
	scanf("%f",&sosyal);
	printf("\n");
	
	printf("Fen Netinizi Girin: ");
	scanf("%f",&fen);
	printf("\n");
	
	toplampuan=Turkce*1.99+matematik*3.998+sosyal*1+fen*2.999+taban;
	
	printf("YKS Puaniniz: %f",toplampuan);*/
	
		
	return 0;
}



