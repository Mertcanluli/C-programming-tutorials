#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	/*float not1,not2,not3,ortalama;
	
	printf("***Puan ve Ortalamaniz\n***");
	
	not1=80;
	not2=75;
	not3=45;
	ortalama=(not1+not2+not3)/3;
	
	printf("Puan Ortalamaniz: %f",ortalama);*/
	
	/*float kisa,uzun,alan,cevre;
	printf("***Dikdortgen alan ve cevre hesabi***\n");
	
	kisa=3.1646;
	uzun=7,6468;
	alan=kisa*uzun;
	cevre=(kisa+uzun)*2;
	
	printf("Dikdortgen Alani: %f\n",alan);
	printf("Dikdortgen Cevresi: %f",cevre);*/

	
	return 0;
}

/* float de�i�keni i�in "%f" kullan�l�r ve int dan ��kan sonucun "virg�ll�" halidir diyebiliriz...

