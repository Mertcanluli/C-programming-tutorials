#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	FILE *metinbelgesi;
	
	char veri1[20]= "Y�netim ";
	char veri2[20]= "Bilisim ";
	char veri3[20]= "Sistemleri ";
	
	metinbelgesi=fopen("C:\\Users\\mertcan\\Desktop\\Deneme2.txt","w");
	
	fputs(veri1,metinbelgesi);
	fputs(veri2,metinbelgesi);
	fputs(veri3,metinbelgesi);
	
	return 0;
}
