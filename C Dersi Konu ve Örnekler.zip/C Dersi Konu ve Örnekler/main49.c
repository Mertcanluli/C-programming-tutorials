#include <stdio.h>
#include <stdlib.h>

 /*int toplam(int s1,int s2)
 {
 	int s3;
 	s3=(s1+s2)*5-10;
 	return s3;
 }

int main() {
	
	int t;
	
	t=toplam(4,5);
	printf("%d\n",t);
	
	t=toplam(2,3);
	printf("%d",t);
	
	return 0;
}
*/



int toplam(int s1, int s2)
{
	int s3;
	s3=(s1+s2)*100-350;
	return s3;
}

int main() {
	
 int s1,s2;
 
    printf("Birinci ve ikinci sayiyi giriniz: \n\n");
    
    scanf("%d",&s1);
    scanf("%d",&s2);
    
    int t;
    
    t=toplam(s1,s2);
    
    printf("Sayilarin toplami= %d",t);
    
    return 0;
	
}
