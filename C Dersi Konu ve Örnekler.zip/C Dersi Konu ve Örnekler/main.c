#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[]) {
	
	printf("!!!! Student Information !!!!\n");
	printf("Name: Mert\n");
	printf("Surname: LULI\n");
	printf("Number: 191005066\n");
	printf("Department: MIS\n");
	printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		return 0;
}

//yazd�r komutu printf ile yap�l�r...
// \n ile alt sat�ra ge�ilir...
// her sat�r sonunda ; koymay� unutma...
