#include <stdio.h>
#include <stdlib.h>
#define Maksimum(s1,s2) (s1>s2) ? s1 : s2



int main() {
	
	printf("%d\n",Maksimum(5,7));
	
	return 0;
}
