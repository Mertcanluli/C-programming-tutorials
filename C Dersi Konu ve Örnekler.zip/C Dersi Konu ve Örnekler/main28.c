#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	// Bir bakteri t�r� her saat ba�� kendini ikiye b�lerek �o�almaktad�r. 24 saat sonunda ka� bakteri olur ???
	
	/*int sayi=1;
	int i;
	
	for(i=1;i<=24;i++)
	{
		sayi=sayi*2;
	}
	printf("%d",sayi);
	*/
	
	
	
	// Klavyeden girilen 4 tam say�n�n toplam�n� veren c kod �rne�i
	
	/*int sayi;
	int i;
	int toplam=0;
	
	for(i=1;i<=4;i++)
	{
		printf("%d.Sayi: ",i);
		scanf("%d",&sayi);
		toplam=toplam+sayi;
	}
	printf("Toplam Sonuc: %d",toplam);
	*/
	
	
	
	// Klavyeden 0 de�eri verilene kadar say�lar�n toplam�n� veren c kodlama �rne�i...
	
	
	
	/*int sayi;
	int toplam=0;
	
	while(sayi!=0)
	{
		printf("Sayi: ");
		scanf("%d",&sayi);
		toplam=toplam+sayi;
	}
	printf("%d",toplam);
	*/
	
	
	
	// Bir otopark da bulunan saat �cret uygulamas�n� c kodu ile yapan �rnek...
	
	
	
	/*int saat;
	
	printf("Saat Giriniz: ");
	scanf("%d",&saat);
	
	if(saat>0 && saat<=4)
	{
		printf("10 TL odeme yapiniz...");
	}
	
	if(saat>=5 && saat<=8)
	{
		printf("12 TL odeme yapiniz...");
	}
	
	if(saat>=9 && saat<=12)
	{
		printf("15 TL odeme yapiniz...");
	}
	
	if(saat>13)
	{
		printf("20 TL odeme yapiniz...");
	}
	*/
	
	
	

	return 0;
}
