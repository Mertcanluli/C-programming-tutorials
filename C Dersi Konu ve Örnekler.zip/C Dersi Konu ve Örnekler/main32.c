#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	int x,y;
	int sonuc;
	
	printf("Taban Degeri: ");
	scanf("%d",&x);
	
	printf("Us Degeri: ");
	scanf("%d",&y);
	
	sonuc=pow(x,y);
	
	printf("Sonuc: %d",sonuc);
	
	// Kuvvet alma i�leminde "pow()" kullan�l�r. 
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}
