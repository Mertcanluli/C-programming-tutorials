#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	
	FILE *dosya;
	
	char karakter[50];
	
	dosya=fopen("C:\\Users\\mertcan\\Desktop\\Deneme.txt","r");
	
	fgets(karakter,15,dosya);
	puts(karakter);
	fclose(dosya);

	return 0;
}
