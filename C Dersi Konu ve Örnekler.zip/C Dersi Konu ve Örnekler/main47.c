#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	char harf='k';
	char *ptr=&harf;
	
	printf("Bellek Adresi: %x\n",ptr); //62fe17
	
	ptr++;
	
	printf("Bellek Adresi: %x\n",ptr); //62fe18
	
	ptr--;
	
	printf("Bellek Adresi: %x\n",ptr); //62fe17
	
	ptr=ptr+5;
	
	printf("Bellek Adresi: %x",ptr); //62fe1c

	return 0;
}
