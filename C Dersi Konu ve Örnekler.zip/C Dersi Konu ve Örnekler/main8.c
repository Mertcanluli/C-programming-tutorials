#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	printf("Ogrenci Ders Basari Hesabi...");
	printf("\n\n");
	
	int s1,s2,ort;
	
	printf("Sinav1 Notunu Giriniz: ");
	scanf("%d",&s1);
	printf("\n");
	
	printf("Sinav2 Notunu Giriniz: ");
	scanf("%d",&s2);
	printf("\n");
	
	ort=(s1+s2)/2;
	printf("Ortalamaniz: %d",ort);
	printf("\n");
	
	if (ort>=50)
	{
		printf("Tebrikler, Basarili oldunuz.");
	}
	else
	{
		printf("Uzgunuz, Basarisiz oldunuz.");
	}
	
	return 0;
}

/* "if else" yap�s�nda dikkat edilmesi gereken ko�ul �ne s�r�l�r. Ard�ndan olumlu ise ba�ka sonu�, olumsuz ise ba�ka sonu� vermesi beklenir...*/
