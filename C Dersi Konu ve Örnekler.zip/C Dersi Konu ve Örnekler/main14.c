#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	/*int i;
	i=1;
	
	while(i<=10)
	{
		printf(" %d",i);
		i++;
	}
	*/
	
	
	
	/* 1 ile 20 aras�ndaki �ift say�lar� alan fakat 14 say�s�n� almayan kod...*/
	
	/*int i;
	i=1;
	
	while(i<=20)
	{
		if(i%2==0 && i!=14)
		{
			printf(" %d",i);
		}
		i++;
	}
	*/
	
	
	
	/*int sayi,faktoryel;
	faktoryel=1;
	sayi=6;
	
	while(sayi>=1)
	{
		faktoryel=faktoryel*sayi;
		sayi--;
	}
	
	printf("Sonuc: %d",faktoryel);
	*/
	
	
	
	/*int sayi, faktoryel;
	faktoryel=1;
	
	printf("Sayiyi Giriniz: ");
	scanf("%d",&sayi);
	
	while(sayi>=1)
	{
		faktoryel=faktoryel*sayi;
		sayi--;
	}
	printf("Sonuc: %d",faktoryel);
	*/
	
	return 0;
}

/* While d�ng�s�nde sadece ko�ul parantez i�inde yaz�l�r... De�i�kene de�er verilecek ise while dan �nce verilir... De�i�kenin artma veya azalma durumu ise
   s�sl� parantez i�inde yaz�l�r...*/
