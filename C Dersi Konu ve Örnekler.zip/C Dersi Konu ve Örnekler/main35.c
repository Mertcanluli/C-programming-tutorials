#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	double sayi,sonucsin,sonuccos;
	
	printf("Sayiyi Giriniz: ");
	scanf("%lf",&sayi);
	
	sonucsin=sin(sayi);
	sonuccos=cos(sayi);
	
	printf("Sinus: %lf\n",sonucsin);
	printf("Cosinus: %lf",sonuccos);
	
	// Sin�s ve Cos�n�s bulmak i�in "sin()" ve "cos()" kullan�l�r...
		
	return 0;
}
