#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	/*int sayac=0;
	int i;
	
	for(i=1;i<=10;i++)
	{
		sayac=sayac+i;
	}
	
	printf("Sayac: %d",sayac);
	*/
	
	
	
	
	/*int i;
	int faktor=1;
	
	for(i=1;i<=5;i++)
	{
		faktor=faktor*i;
	}
	
	printf("5 sayisinin faktoryel degeri: %d",faktor);
	*/
	
	
	
	/*int i, sayi;
	int faktoryel=1;
	
	printf("Hesaplanacak Degeri Giriniz: ");
	scanf("%d",&sayi);
	
	for(i=1;i<=sayi;i++)
	{
		faktoryel=faktoryel*i;
	}
	
	printf("Sonuc: %d",faktoryel);
	*/
	
	
	
	return 0;
}
