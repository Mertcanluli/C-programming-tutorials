#include <stdio.h>
#include <stdlib.h>

/*int kupbul(int sayi)
    {
    	int sonuc=sayi*sayi*sayi;
    	return sonuc;
    
	}

int main() {
	
	int s;
	
	printf("Sayiyi Giriniz: ");
	scanf("%d",&s);
	
	printf("\n\nSonuc: %d",kupbul(s));
	
	return 0;
}
*/



void dortgen(int kisa, int uzun)
{
	int i,j;
	for(i=0;i<uzun;i++)
	{
		for(j=0;j<kisa;j++)
		{
			printf("*");
		}
		printf("\n");
	}
}

int main()
{
	dortgen(10,5);
	
	return 0;
}



